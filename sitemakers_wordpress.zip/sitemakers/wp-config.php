<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sitemakers');

/** MySQL database username */
define('DB_USER', 'sitemakers');

/** MySQL database password */
define('DB_PASSWORD', 'Makers@1213');

/** MySQL hostname */
define('DB_HOST', 'sitemakers.db.5708265.hostedresource.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '98TeU2:I9eL__f{`p0gB}pL-+|`q}N:_NI-uq,u[9GQWR]%x$oQS GCQ~OXjhKL6');
define('SECURE_AUTH_KEY',  'c)bY#=(VV?#k7>21)DQ{+gzK{0_z}>7;ZcZ*KTovsE|ZNpzXQ%mX~+4]+?Rg_[u6');
define('LOGGED_IN_KEY',    '7,d.3t/kKjp#i@ObLk,*Ed}8iT$nt}B:$5-3|G?)bKM @V{tI}E0aJh,9|_7xMC`');
define('NONCE_KEY',        'Dg0S:8(%s-~T.)d#oR !{&^J|O4;7~CgFY;uomaMUvMSA%]s|u,H;bh_K]O7~-iu');
define('AUTH_SALT',        'A10ByuB|xy6Qb cJS#1u!Or=i8N}Gyb-,om3[Fkz-05|qw|3 TZplusYux,.+1?n');
define('SECURE_AUTH_SALT', '+I`N=NyT6diR$*y~W/i &`U,fCNpyzNbE5Bo6mUjxT=AT~{5c+.AC@C%z8?{&d+L');
define('LOGGED_IN_SALT',   'YX<|Mch~}D3ykb|MH-6;x_^u^[,A,I(%5K8I0yj5HDT6kN3K1y<{Tl;63Y9Wb5TH');
define('NONCE_SALT',       '~ToMn+U-^B|cV~Vx<kAnPu?#p 3$O?_]&Dg>. _Gd:5Xe~LV+h -<t*zQ4N-4TwV');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
